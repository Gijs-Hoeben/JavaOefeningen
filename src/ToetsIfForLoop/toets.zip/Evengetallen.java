package ToetsIfForLoop;

public class Evengetallen {

	public static void main(String[] args) {
		Evengetallen evengetal = new Evengetallen();
		
		
		
		for(int i = -20; i > -50; i--) {
			if(i % 2 == 0 && (i != 40)); {
				System.out.println(i);
			}
		
		}
			
	}
}
